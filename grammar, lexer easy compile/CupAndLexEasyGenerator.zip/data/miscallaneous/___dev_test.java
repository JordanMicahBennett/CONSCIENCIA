import data.packages.UNICODE.*;

public class Test
{
    public static void main ( )
    {
        UNICODE_ConveniencePack conveniencePack = new UNICODE_ConveniencePack ( );
        UNICODE_ConfigurationManager configurationManager = new UNICODE_ConfigurationManager ( "data/config/config.ini" );
        
        String rawLexerContent = conveniencePack.getFileContent ( "data/output/" + "lexTest" + ".java" ).replaceAll ( "data/output/", "" );
        String customLexerClassName = "AlternateLexClassNAme";
        
        //enable package name customization
        String patternStringb = "[^(\\()(\\s+)]+(\\.)runtime(\\.)";
        String replacementControllerStringb = configurationManager.getCupPackageNameFileFromFile ( ) + "$1runtime$2";
        String rawLexerContentb = conveniencePack.getRegexComponents ( patternStringb, rawLexerContent, replacementControllerStringb ); 
    
        //enable lexer class name customization
        String patternStringc = "(\\w+)(\\s+)Lexer";
        String replacementControllerStringc = "$1$2" + customLexerClassName;
        String refinedLexerContent = conveniencePack.getRegexComponents ( patternStringc, rawLexerContentb, replacementControllerStringc ); 
        
        System.out.println ( refinedLexerContent );
    }
}