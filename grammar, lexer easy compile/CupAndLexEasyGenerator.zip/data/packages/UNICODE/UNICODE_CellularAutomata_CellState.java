package data.packages.UNICODE; 
//author: jordan micah bennett
public enum UNICODE_CellularAutomata_CellState { DEAD, ALIVE }