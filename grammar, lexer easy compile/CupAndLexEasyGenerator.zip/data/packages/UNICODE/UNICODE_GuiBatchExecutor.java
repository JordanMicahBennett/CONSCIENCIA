package data.packages.UNICODE; //Author(s): Jordan Micah Bennett
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.File;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

//NOTE This is not an actual compilet. This just utilizes standard javac utility.

public class UNICODE_GuiBatchExecutor
{
	//attributes
	private Runtime runtime = null;
	private Process process = null;
	
	public Runtime getRuntime ( )
	{
		return runtime;
	}
	
	public Process getProcess ( )
	{
		return process;
	}
	
    //1.gets from a file, data representing a tempate of what a java executing batch file should contain.
    public ArrayList getGenericCompilationFileData ( String fileStream )
    {
        ArrayList value = new ArrayList ( );
        try
        {
            Scanner scanner = new Scanner ( new File ( fileStream ) );
            while ( scanner.hasNext ( ) )
                value.add ( scanner.nextLine ( ) );
            scanner.close ( );
        }
        catch ( Exception error ) { }
        return value;
    }

    
    //3.Generates batch file based on compilation specifics.
    public void generateBatch ( ArrayList specificCompilationFileData, String fileStream )
    {
        try
        {
            PrintWriter printWriter = new PrintWriter ( fileStream );
            
            for ( int i = 0; i < specificCompilationFileData.size ( ); i ++ )
                printWriter.println ( specificCompilationFileData.get ( i ) );
            printWriter.close ( );
        }
        catch ( Exception error ) { }
    }
	
    //3.Generates batch file based on compilation specifics.
    public void generateBatch ( String specificCompilationFileData, String fileStream )
    {
        try
        {
            PrintWriter printWriter = new PrintWriter ( fileStream );
            
            printWriter.println ( specificCompilationFileData );
            printWriter.close ( );
        }
        catch ( Exception error ) { }
    }
    
    //4.executes batch commands.
    //this is used to execute the batch file enerated above.
    public void executeBatch ( String command )
    {
        try
        {  
            runtime = Runtime.getRuntime ( );
            process = runtime.exec ( command );
            process.waitFor ( );
        }
        catch ( Throwable throwable ) { throwable.printStackTrace ( ); };
    }
	
    //5.Compile and run java class
    public void generateResult ( String compileTemplateStream, String outputBatchFileName, ArrayList _specificCompilationFileData )
    {
        //1.establish generic compilation file data
        ArrayList genericCompilationFileData = getGenericCompilationFileData ( compileTemplateStream );
        
        //2.establish specific compilation file data, javac directory, and a java file.
        ArrayList specificCompilationFileData = _specificCompilationFileData;
        
        //3.generate batch file with specific compilation data
        generateBatch ( specificCompilationFileData, outputBatchFileName + ".bat" );
        
        //4.execute batch file generate above.
        executeBatch ( "cmd /c start " + outputBatchFileName + ".bat" );
    }
	
    //5.Compile and run java class
    public void generateResult ( String compileTemplateStream, String outputBatchFileName, String _specificCompilationFileData )
    {
        //1.establish generic compilation file data
        ArrayList genericCompilationFileData = getGenericCompilationFileData ( compileTemplateStream );
        
        //2.establish specific compilation file data, javac directory, and a java file.
        String specificCompilationFileData = _specificCompilationFileData;
        
        //3.generate batch file with specific compilation data
        generateBatch ( specificCompilationFileData, outputBatchFileName + ".bat" );
        
        //4.execute batch file generate above.
        executeBatch ( "cmd /c start " + outputBatchFileName + ".bat" );
    }
}