package data.packages.UNICODE; //Author(s): Jordan Micah Bennett
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;
import java.awt.Color;
import java.util.ArrayList;
import java.awt.Dimension;

public class UNICODE_ConfigurationManager
{
    // attributes
        //establish opacity level variables
        private ArrayList config_lines = new ArrayList ( );
        private String [ ] config_labels = 
                                            {
												"colour::",
												"buffer-dimension::",
												"font-name::",
												"app-opacity::",
												"java-location::",
												"system-type::",
												"cup-package-name::",
												"lex-package-name::"
                                            };
                                        
        //string to colour conterter
        private UNICODE_StringToColourConverter string_to_colour_converter = new UNICODE_StringToColourConverter ( );
        
        //establish convenience pack
        private UNICODE_ConveniencePack conveniencePack = new UNICODE_ConveniencePack ( );
        
    //constructor
    public UNICODE_ConfigurationManager ( String configurationFileStream )
    {
        loadConfigData ( configurationFileStream );
    }
    
    //load config data
    public void loadConfigData ( String configurationFileStream )
    {
        //generate config lines
        try
        {
            int count = 0;
            Scanner scanner = new Scanner ( new File ( configurationFileStream ) );
            while ( scanner.hasNext ( ) ) 
            {
               config_lines.add ( scanner.next ( ) );
            }
            scanner.close ( );
        }
        catch ( Exception error )
        {
        }   

    }
	
    //get colour from file, so program can know what colour to start with 
    public Color getColourFromFile ( )
    {
        Color colour = null;
        
        //convert array list index 0, colour config line to a string separated by spaces
        String [ ] rgb_array = conveniencePack.getDelimitedArray ( conveniencePack.getDelimitedArray ( ( String ) config_lines.get ( 0 ), "", "::", 2 ) [ 1 ], "", ",", 3 );
        String colour_string = rgb_array [ 0 ] + " " + rgb_array [ 1 ] + " " + rgb_array [ 2 ];
        
        //convert the string into a fucking colour 
        colour = string_to_colour_converter.getColourFromString ( colour_string.replace ( "null", "" ) );

        //return the fucking colour
        return colour;
    }
	
    //get buffer dimension from file
    public Dimension getBufferDimensionFromFile ( )
    {
		Dimension returnValue = null;
		
        String bufferDimensionString = bufferDimensionString = conveniencePack.getDelimitedArray ( ( String ) config_lines.get ( 1 ), "", "::", 2 ) [ 1 ];
		
		int width = Integer.parseInt ( conveniencePack.getDelimitedArray ( bufferDimensionString, "", ",", 2 ) [ 0 ] );
		int height = Integer.parseInt ( conveniencePack.getDelimitedArray ( bufferDimensionString, "", ",", 2 ) [ 1 ] );
		
		returnValue = new Dimension ( width, height );
		
		return returnValue;
	}
	
    //getFontStreamStringFromFile from file
    public String getFontStreamStringFromFile ( )
    {
        String value = null;
        
        value = conveniencePack.getDelimitedArray ( ( String ) config_lines.get ( 2 ), "", "::", 2 ) [ 1 ];
        
        return value;
    }

    //get opacity from file, so program can know what opacity to start with
    public float getOpacityFromFile ( )
    {
        float opacity = 0.0f;
        opacity = Float.parseFloat ( conveniencePack.getDelimitedArray ( ( String ) config_lines.get ( 3 ), "", "::", 2 ) [ 1 ] );
        return opacity;
    }
		
    //getJavacLocation from file
    public String getJavacLocationFromFile ( )
    {
        String value = null;
        
        value = conveniencePack.getDelimitedArray ( ( String ) config_lines.get ( 4 ), "", "::", 2 ) [ 1 ];
        
        return value;
    }	
	
    //getSystemTypeStringFromFile from file
    public String getSystemTypeStringFromFile ( )
    {
        String value = null;
        
        value = conveniencePack.getDelimitedArray ( ( String ) config_lines.get ( 5 ), "", "::", 2 ) [ 1 ];
        
        return value;
    }	
	
    //getCupPackageNameFile from file
    public String getCupPackageNameFileFromFile ( )
    {
        String value = null;
        
        value = conveniencePack.getDelimitedArray ( ( String ) config_lines.get ( 6 ), "", "::", 2 ) [ 1 ];
        
        return value;
    }	
	
    //getLexPackageNameFile from file
    public String getLexPackageNameFileFromFile ( )
    {
        String value = null;
        
        value = conveniencePack.getDelimitedArray ( ( String ) config_lines.get ( 7 ), "", "::", 2 ) [ 1 ];
        
        return value;
    }	
	
    //update javac path controller
    public void updateJavacLocationController ( UNICODE_JavacLocationController javacLocationController )
    {
        //set Method Package Regex Usage Answer
        config_lines.set ( 4, config_labels [ 4 ] + javacLocationController.getValue ( ) );
        //print the config array list contents
        updateConfigFile ( );
    }	
	
    //update system type string controller
    public void updateSystemTypeController ( UNICODE_SystemTypeController systemTypeController  )
    {
        //set Method Package Regex Usage Answer
        config_lines.set ( 5, config_labels [ 5 ] + systemTypeController.getValue ( ) );
        //print the config array list contents
        updateConfigFile ( );
    }	
	
    public void updateConfigFile ( )
    {
        try
        {
            PrintWriter pw = new PrintWriter ( new FileWriter ( "data/config/CONFIG.ini" ) );
            for ( int configs = 0; configs < config_lines.size ( ); configs ++ )
                pw.println ( config_lines.get ( configs ) );
            pw.close ( );
        }
        catch ( Exception error )
        {
        }  
    }
	
	public void defineLabels ( String label_string, String delimiter )
	{
		config_labels = conveniencePack.makeArray ( label_string, delimiter );
	}
	
	public String [ ] getConfigLabels ( )
	{
		return config_labels;
	}
}
