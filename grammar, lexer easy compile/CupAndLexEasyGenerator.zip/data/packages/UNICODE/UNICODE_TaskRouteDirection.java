package data.packages.UNICODE;

public enum UNICODE_TaskRouteDirection { FORWARD, REVERSE };