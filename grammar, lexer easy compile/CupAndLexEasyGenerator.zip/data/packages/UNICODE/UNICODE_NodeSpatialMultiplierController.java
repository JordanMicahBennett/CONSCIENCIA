package data.packages.UNICODE; //Author(s): Jordan Micah Bennett

public class UNICODE_NodeSpatialMultiplierController
{
    //attributes
    private int value = 0;

    public UNICODE_NodeSpatialMultiplierController ( int _value )
    {
        value = _value;
    }
    
    //methods
        //accessors
        public int getValue ( )
        {
            return value;
        }
        //mutators
        public void setValue ( int value )
        {
            value = value;
        }

}
