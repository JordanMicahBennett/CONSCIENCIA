package data.packages.UNICODE; 
//:---------------------------------------------:
//:--: Author: Jordan Micah Bennett
//:---------------------------------------------:
//establish direction constants
public enum UNICODE_FadePaintDirections { UPWARD, DOWNWARD, LEFTWARD, RIGHTWARD, UPWARDANDRIGHTWARD }