package data.packages.UNICODE; //Author(s): Jordan Micah Bennett

public class UNICODE_ProcessExecutionSpeedController
{
    //attributes
    private double value = 0.00;

    public UNICODE_ProcessExecutionSpeedController ( )
    {
    }
    
    //methods
        //accessors
        public double getValue ( )
        {
            return value;
        }
        //mutators
        public void setValue ( double value )
        {
            this.value = value;
        }

}
