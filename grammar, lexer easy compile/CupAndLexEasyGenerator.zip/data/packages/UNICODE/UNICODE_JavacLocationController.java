package data.packages.UNICODE; //Author(s): Jordan Micah Bennett

public class UNICODE_JavacLocationController
{
    //attributes
    private String value = null;

    public UNICODE_JavacLocationController ( String value )
    {
        this.value = value;
    }
    
    //methods
        //accessors
        public String getValue ( )
        {
            return value;
        }
        //mutators
        public void setValue ( String value )
        {
            this.value = value;
        }

}
