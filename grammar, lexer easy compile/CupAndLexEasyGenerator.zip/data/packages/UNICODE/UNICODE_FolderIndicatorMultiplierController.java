package data.packages.UNICODE; //Author(s): Jordan Micah Bennett

public class UNICODE_FolderIndicatorMultiplierController
{
    //attributes
    private int value = 0;

    public UNICODE_FolderIndicatorMultiplierController ( int _value )
    {
        value = _value;
    }
    
    //methods
        //accessors
        public int getValue ( )
        {
            return value;
        }
        //mutators
        public void setValue ( int value )
        {
            value = value;
        }

}
