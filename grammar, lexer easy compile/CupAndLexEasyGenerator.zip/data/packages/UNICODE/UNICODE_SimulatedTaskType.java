package data.packages.UNICODE;

public enum UNICODE_SimulatedTaskType { NEW, WAITING, RUNNING, READY, TERMINATED };